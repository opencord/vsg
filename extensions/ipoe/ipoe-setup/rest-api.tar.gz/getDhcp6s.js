/**
 * File:         getDhcp6s.js
 * Contents:     get data from dhcp6s.conf
 */

var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
module.exports= {
    getDhcp6s: function(content) {
        var result = "{'config_file_name':'dhcp6s.conf','config_file_contents':[{";
        var str = content.split('\n')
        var flagInitObj = true;
        var flagkeyinfo = true;
        var flaghost = true;
        if(str.length>0)
        {
            for(var i = 0 ; i < str.length-1; i++) {
                var strr='';
                if(str[i].match("#") !== null )  {
                    continue;
                } else {
                    if(str[i].match("option")) {
                        var spistr = commonOper.rep_spi_space(str[i]);
                       // console.log("==== ***enter ====str[0]:"+ spistr[0] +"===str[1]:"+spistr[1]+ "====str[2]"+spistr[2]);
                        if(spistr[2].indexOf("\"")>-1) {
                            spistr[2] = spistr[2].substring(1,spistr[2].length-1);
                        }
                        if(flagInitObj) {
                            strr += '\"' + spistr[1]+ '\":\"' + spistr[2].substring(0,spistr[2].length-1) + '\"';
                            flagInitObj = false;
                        } else {
                            strr += ',\"' + spistr[1]+ '\":\"' + spistr[2].substring(0,spistr[2].length-1) + '\"';
                        }
                    }
                    if(str[i].match("keyinfo") || str[i].match("host")) {
                        if(str[i].match("keyinfo")) {
                            flagkeyinfo = true;
                        }
                       if(str[i].match("host")) {
                           flaghost = true;
                       }
                        var spistr = commonOper.rep_spi_space(str[i]);
                        if(flagInitObj) {
                            strr += '\"' + spistr[1] + '\":{\"' ;
                            flagInitObj = false;
                        } else {
                            strr += ',\"' + spistr[1] + '\":{\"' ;
                        }
                    }
                    if(str[i].match("realm") || str[i].match("keyid") || str[i].match("secret") ||
                        str[i].match("duid") || str[i].match("prefix") || str[i].match("address") ||
                        str[i].match("delayedkey")) {
                        if(str[i].match("delayedkey") || str[i].match("keyinfo") ||
                            str[i].match("sip-server-address") ) {
                            if(flaghost) {
                                result += strr;
                                continue;
                            }
                        }
                        str[i] = str[i].replace(/(^\s*)|(\s*$)/g, "");
                        if(str[i].match("address-pool")) {
                            var tmpstr = str[i-1].split(" ");
                            strr += ',\"'+tmpstr[0] +'\":{'
                            strr += '\"'+ "value" + '\":\"' +tmpstr[1] + '\"';
                            var spistr = str[i].split(" ");
                            strr += ',\"' + spistr[0]+ '\":\"' + spistr[2].substring(0,spistr[1].length-1) + '\"}';
                        } else {
                            var spistr = str[i].split(" ");
                            if(spistr[1].indexOf("\"")>-1) {
                                spistr[1] = spistr[1].substring(1,spistr[1].length-1);
                            }
                            if(flagkeyinfo) {
                                strr +=  spistr[0]+ '\":\"' + spistr[1].substring(0,spistr[1].length-1) + '\"';
                                flagkeyinfo = false;
                            } else {
                                if(flaghost) {
                                    if(str[i-1].match("host")) {
                                        if(str[i].match("address")) {
                                            strr +=  spistr[0]+ '\":\"' + spistr[1] + '\"';
                                        } else {
                                            strr +=  spistr[0]+ '\":\"' + spistr[1].substring(0,spistr[1].length-1) + '\"';
                                        }
                                        flaghost = false;
                                    } else {
                                        if(str[i].match("address")) {
                                            strr += ',\"' + spistr[0]+ '\":\"' + spistr[1] + '\"';
                                        } else {
                                            strr += ',\"' + spistr[0]+ '\":\"' + spistr[1].substring(0,spistr[1].length-1) + '\"';
                                        }
                                    }
                                } else {
                                    if(str[i].match("address")) {
                                        strr += ',\"' + spistr[0]+ '\":\"' + spistr[1] + '\"';
                                    } else {
                                        strr += ',\"' + spistr[0]+ '\":\"' + spistr[1].substring(0,spistr[1].length-1) + '\"';
                                    }
                                }
                            }
                            if(str[i+1].match("};")) {
                                strr += '}';
                            }
                        }
                    }
                    if(str[i].match("range")) {
                        var spistr = commonOper.rep_spi_space(str[i]);
                        strr += ',\"' +"pool" + '\":{\"' +"ipoe_ipv6_addr_low" +'\":\"'+spistr[1] +'\",\"'
                            +"ipoe_ipv6_addr_high"+'\":\"'+spistr[3].substring(0,spistr[3].length-1) +"\"}";
                    }
                }
                result += strr;
            }
        }
        result += '}]}';
        return result;
    }//Parsing dhcp6s.conf files
}




