/**
 * File:         formatDate.js
 * Contents:     time format
 */


module.exports= {
     format:function(time, format) {
        var t = new Date(time);
        var tf = function formatTen(num) {
            return num > 9 ? (num + "") : ("0" + num);
        }
        return format.replace(/yyyy|MM|dd|HH|mm|ss/g, function(a){
            switch(a){
                case 'yyyy':
                    return tf(t.getFullYear());
                    break;
                case 'MM':
                    return tf(t.getMonth() + 1);
                    break;
                case 'mm':
                    return tf(t.getMinutes());
                    break;
                case 'dd':
                    return tf(t.getDate());
                    break;
                case 'HH':
                    return tf(t.getHours());
                    break;
                case 'ss':
                    return tf(t.getSeconds());
                    break;
            }
        })
    }
}