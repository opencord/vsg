/**
 * File:         stopServer.js
 * Contents:     stop all server process
 */

var Promise=require('bluebird')
var execAsync=Promise.promisify(require('child_process').exec);
var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');

module.exports={
    stop:function(command,key,msg,name,cmd_kill) {
        return execAsync(command).then(function(content){
            var str = content.split('\n');
            if(str.length>0) {
                var flag = true;
                for (var i = 0; i < str.length - 1; i++) {
                    if(str[i].match(key)) {
                        console.log(str[i]);
                        var ss = str[i].replace(/\s+/g, ' ');
                        var spistr = commonOper.rep_spi_space(ss);
                        if(flag) {
                            flag = false;
                            if(name == "dhcp6s") {
                                execAsync("sudo kill -9  " + parseInt(spistr[1])).then(function(err){
                                    if (err && name == "radvd") reject(err);
                                    return {"status":msg};
                                });
                            } else {
                                execAsync(cmd_kill + parseInt(spistr[1])).then(function(err){
                                    if (err && name == "radvd") reject(err);
                                    return {"status":msg};

                                });
                            }
                        }
                    }
                }
            }
        });
    },
    stopDocker: function(updateData){
        console.log("disable docker");
        var cmd = "sudo /home/ubuntu/reinit-vcpe-docker.sh "+ updateData["docker-name"];
        console.log("disable docker cmd: "+cmd);
        return execAsync(cmd).then(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"status":"docker  " + updateData["docker-name"] +"  " +updateData.operation +" success!"};
        });
    },
    startDocker: function(updateData) {
        var cmd = "sudo /home/ubuntu/setup-vcpe-docker.sh "+ updateData["docker-name"] + "  wide-dhcp6.vars";
        console.log("cmd: "+cmd);
        return execAsync(cmd).then(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"status":"docker  " + updateData["docker-name"] +"  " +updateData.operation +" success!"};
        });
    },
    restartDocker:function(updateData) {
        console.log("enable docker");
        var cmd_stop = "sudo docker restart "+ updateData["docker-name"];
        var cmd_start = "/home/ubuntu/setup-vcpe-docker.sh "+ updateData["docker-name"] + "  wide-dhcp6.vars";
        console.log("enable docker cmd_stop :"+cmd_stop);
        execAsync(cmd_stop).then(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            console.log("enable docker cmd_start :"+cmd_start);
            execAsync(cmd_start)
        })
        //setTimeout(function(){
           // execAsync(cmd_start)
       // },1000*2);
        return{"status":"docker  " + updateData["docker-name"] +"  " +updateData.operation +" success!"};
    }
}