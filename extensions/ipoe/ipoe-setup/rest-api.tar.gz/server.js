/**
 * File:         server.js
 * Contents:     create/get/update/delete configuration files
 */

var jsonServer = require('json-server');
var server = jsonServer.create();
var router = jsonServer.router('db.json');
var middlewares = jsonServer.defaults();
var __dirname = "/usr/local/lib/node_modules";
var Promise=require('bluebird');
var execAsync=Promise.promisify(require('child_process').exec);

var getOper = require(__dirname + '/getConfData');
var updateOper = require(__dirname + '/updateConf');
var restartOper = require(__dirname + '/restartServer');
var getDockernames = require(__dirname + '/getDockerNames');
var getRequestData= require(__dirname + '/getRequestPar');
var stopAllOper = require(__dirname + '/stopAllServer');
var startAllOper = require(__dirname + '/startAllServer');
var stopOper = require(__dirname + '/stopServer');
var generateServer6LeasesOpr = require(__dirname + '/generateServer6Leases');
// Set default middlewares (logger, static, cors and no-cache)

var wideDhcp6cVarPath = "/cord/ipoe-setup/wide-dhcp6.vars";
var port = 9020;
//var wideDhcp6cVarPath = "/home/ubuntu/ipoe/ipoe-setup/wide-dhcp6.vars";
server.use(middlewares)
var arguments = process.argv.splice(2);
console.log('arguments:', arguments);

if(arguments.length > 1) {
    port = arguments[0];
    wideDhcp6cVarPath = arguments[1];
}
console.log({"port":port,"wideDhcp6cVarPath":wideDhcp6cVarPath});

server.get("/ipoe/systemVars",function(req,res){
    var resProm = getOper.getDhcp6VarsData(wideDhcp6cVarPath);
    if(resProm !== undefined) {
        resProm.then(function(data){
            console.log(data);
            res.send(data);
        })
    } else {
        res.send({"state":"Get wide-dhcp6.vars data error."});
    }
})

server.put('/ipoe/systemVars',function(req,res){
    var updateData = "";
    req.on('data', function (data) {
        var reqData = data.toString();
        console.log("reqData:" +reqData);
        updateData = getRequestData.getSystemVarsReqData(reqData);
        //updateData = JSON.parse(data.toString());
    })
    req.on('end',function(){
        console.log("enter update variables start");
        console.log(updateData);
        /*var resProm = getOper.getDhcp6VarsData(wideDhcp6cVarPath);
        var Dhcp6VarsData = "";
        if(resProm !== undefined) {
            resProm.then(function(data){
                console.log("Dhcp6VarsData:");
                console.log(data);
                Dhcp6VarsData = data;
            })
        }*/
        if(updateData == "" || updateData == {}) {
            res.jsonp({"message":"Request parameter format error."});
        } else {
            var resProm = updateOper.updateVariables(wideDhcp6cVarPath,updateData);
            if(resProm !== undefined) {
                var path = wideDhcp6cVarPath.replace(/wide-dhcp6.vars/, "").replace(/(^\s*)|(\s*$)/g, "");
                var cmd = path +"reinit-ipoe-server.sh";
                console.log("reinit ipoe cmd: "+cmd);
                execAsync(cmd);
                var respData = {"state":true};
                res.jsonp(respData)
            } else {
                res.jsonp({"state":false});
            }
        }
    })
})

server.get('/ipoe/dhcp6s',function(req,res){
    var updateData = "";
    req.on('data', function (data) {
        var reqData = data.toString();
        console.log(reqData);
        updateData = getRequestData.getDhcp6sReqData(reqData);
    })
    req.on('end',function(){
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter or url or method error."});
        } else {
            var resProm ="";
            if(updateData.type  !== undefined) {
                console.log("enter dhcp6s " + updateData.type + " start");
                if(updateData.type == "config") {
                    resProm = getOper.getDhcp6sData();
                } else if(updateData.type == "status") {
                    resProm = getOper.getServerStatus("wide-dhcp6s","ps -aux |grep dhcp6s","/usr/sbin/dhcp6s");
                } else if(updateData.type == "leases") {
                    resProm = generateServer6LeasesOpr.generateDhcp6sLease();
                }
            }
            if(resProm !== undefined && resProm !== "") {
                console.log(resProm);
                resProm.then(function(data){
                    console.log(data);
                    res.jsonp(data)
                })
            } else {
                if(updateData.operation !== undefined) {
                    res.jsonp({"state":" Not supported "+updateData.operation +" operation,please check method!"});
                } else {
                    res.jsonp({"state":false});
                }
            }
        }
    })
})

server.post('/ipoe/dhcp6s',function(req,res){
    var updateData = "";
    req.on('data', function (data) {
        var reqData = data.toString();
        console.log(reqData);
        updateData = getRequestData.getDhcp6sReqData(reqData);
    })
    req.on('end',function(){
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter or url error."});
        } else {
            var resProm ="";
            if(updateData.operation  !== undefined) {
                console.log("enter dhcp6s " + updateData.operation + " operation");
                resProm =restartOper.dhcp6sOperation(updateData);
            }
            if(resProm !== undefined && resProm !== "") {
                console.log(resProm);
                resProm.then(function(data){
                    console.log(data);
                    res.jsonp(data)
                })
            } else {
                if(updateData.operation !== undefined) {
                    res.jsonp({"state":" Not supported "+updateData.type +" operation,please check method!"});
                } else {
                    res.jsonp({"state":false});
                }
            }
        }
    })
})

server.get('/ipoe/dhcp6c',function(req,res) {
    var updateData = "";
    req.on('data', function (data) {
        console.log(data.toString());
        updateData = data.toString();
        updateData = getRequestData.getRequestData(updateData);
    })
    req.on('end',function(){
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter type or docker-name or url error."});
        } else {
            var resProm ="";
            if(updateData.type  !== "" && updateData["docker-name"] !== "") {
                console.log("enter dhcp6c " + updateData.type + " start");
                var tag = updateData["docker-name"].split("-");
                var stag = tag[1];
                var ctag = tag[2];
                console.log("enter dhcp6c stag " + stag + " ctag "+ctag);
                if(updateData.type == "config") {
                    resProm = getOper.getDhcp6cData(stag,ctag,updateData["docker-name"]);
                } else if(updateData.type == "status") {
                    var cmd = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'ps -aux |grep dhcp6c'";
                    resProm = getOper.getDhcpv6cStatus("wide-dhcp6c",cmd,"dhcp6c");
                } else if(updateData.type == "leases") {
                    console.log("====leases ====");
                    resProm = getOper.getDhcp6cLeaseInfo(updateData["docker-name"]);
                    //res.jsonp({"state":"No Lease information available"});
                }
            }
            if(resProm !== undefined && resProm !== "") {
                if(resProm.then !== undefined) {
                    resProm.then(function(data){
                        console.log(data);
                        res.jsonp(data)
                    })
                }else{
                    if(updateData.operation !== undefined) {
                        res.jsonp({"state":" Not supported "+updateData.operation +" operation,please check method!"});
                    } else {
                        res.jsonp({"state":"success"});
                    }
                }

            } else {
                if(updateData.operation !== undefined) {
                    res.jsonp({"state":" Not supported "+updateData.operation +" operation,please check method!"});
                } else {
                    res.jsonp({"state":"Docker is not running or IPv6 is not enabled"});
                }
            }
        }
    })
})

server.post('/ipoe/dhcp6c',function(req,res){
    var updateData = "";
    req.on('data', function (data) {
        console.log(data.toString());
        updateData = data.toString();
        updateData = getRequestData.getRequestData(updateData);
    })
    req.on('end',function() {
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter operation or docker-name or url error."});
        } else {
            var resProm ="";
            if(updateData.operation  !== "" && updateData["docker-name"] !== "") {
                console.log("enter dhcp6c " + updateData.operation);
                console.log("docker-name "+updateData["docker-name"]);
                if(updateData["docker-name"] == "all") {
                    resProm = getDockernames.getAllDockerNames(updateData);
                } else {
                    if(updateData.operation == "disable")  {
                        resProm = stopOper.stopDocker(updateData);
                    } else if(updateData.operation == "enable") {
                        resProm = stopOper.restartDocker(updateData);
                    }else if(updateData.operation == "stop") {
                        resProm = stopAllOper.stopAll(updateData);
                    }else if (updateData.operation == "start") {
                        resProm =restartOper.dhcp6cOperation(updateData);
                    }else if(updateData.operation == "restart") {
                        resProm = startAllOper.startAll(updateData);
                    }
                }
            }
            if(resProm !== undefined && resProm !== "")  {
                if(resProm.then !== undefined) {
                    resProm.then(function(data){
                        console.log(data);
                        if(updateData.operation == "stop" || updateData.operation == "restart" || updateData.operation == "enable") {
                            setTimeout(function(){
                                res.jsonp(data);
                            },1000*10);
                        } else {
                            res.jsonp(data);
                        }
                    })
                }else{
                    if(updateData.operation == "stop" || updateData.operation == "restart" || updateData.operation == "enable") {
                        setTimeout(function(){
                            res.jsonp({"status":"docker  " + updateData["docker-name"] +"  " +updateData.operation +" success!"});
                        },1000*10);
                    } else {
                        res.jsonp({"status":"docker  " + updateData["docker-name"] +"  " +updateData.operation +" success!"});
                    }
                }
            } else {
                if(updateData.type !== undefined ||  updateData.type !== "") {
                    res.jsonp({"message":"Request parameter "+ updateData.type+"operation or docker-name error,please check method!"});
                } else {
                    res.jsonp({"state":"Docker is not running or IPv6 is not enabled"});
                }
            }
        }
    })
})



server.get('/ipoe/radvd',function(req,res){
    var updateData = "";
    req.on('data', function (data) {
        console.log(data.toString());
        updateData = data.toString();
        updateData = getRequestData.getRequestData(updateData);
    })
    req.on('end',function(){
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter  type or docker-name error."});
        } else {
            var resProm ="";
            if(updateData.type  !== "" && updateData["docker-name"] !== "") {
                console.log("enter radvd " + updateData.type + " start");
                if(updateData.type == "config") {
                    resProm = getOper.getRadvdData(updateData["docker-name"]);
                } else if(updateData.type == "status") {
                    var cmd = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'ps -aux |grep radvd'";
                    resProm = getOper.getRadvdServerStatus(cmd);
                } else if(updateData.type == "leases") {
                    res.jsonp({"state":"No Lease information available"});
                }
            }
            if(resProm !== undefined && resProm !== "") {
                if(resProm.then !== undefined) {
                    resProm.then(function(data){
                        console.log(data);
                        res.jsonp(data)
                    })
                }else{
                    res.jsonp({"state":"success"});
                }
            } else {
                if(updateData.operation !== undefined) {
                    res.jsonp({"message":"Request parameter"+ updateData.operation+"operation or docker-name error,please check method!"});
                } else {
                    res.jsonp({"state":"Docker is not running or IPv6 is not enabled"});
                }
            }
        }
    })
})

server.post('/ipoe/radvd',function(req,res){
    var updateData = "";
    req.on('data', function (data) {
        console.log(data.toString());
        updateData = data.toString();
        updateData = getRequestData.getRequestData(updateData);
    })
    req.on('end',function(){
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter operation or docker-name error."});
        } else {
            var resProm ="";
             if(updateData.operation  !== "" && updateData["docker-name"] !== "") {
                console.log("enter radvd " + updateData.operation + " operation");
                resProm = restartOper.radvdOperation(updateData);
            }
            if(resProm !== undefined && resProm !== "") {
                if(resProm.then !== undefined) {
                    resProm.then(function(data){
                        console.log(data);
                        res.jsonp(data)
                    })
                }else{
                    res.jsonp({"state":"success"});
                }
            } else {
                if(updateData.type !== undefined) {
                    res.jsonp({"message":"Request parameter"+ updateData.type+"operation or docker-name error,please check method!"});
                } else {
                    res.jsonp({"state":"Docker is not running or IPv6 is not enabled"});
                }
            }
        }
    })
})


server.get('/ipoe/dibbler-server',function(req,res){
    var updateData = "";
    req.on('data', function (data) {
        console.log(data.toString());
        updateData = data.toString();
        updateData = getRequestData.getRequestData(updateData);
    })
    req.on('end',function(){
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter type or docker-name error."});
        } else {
            var resProm ="";
            if(updateData.type  !== "" && updateData["docker-name"] !== "") {
                console.log("enter dibbler " + updateData.type + " start");
                if(updateData.type == "config") {
                    resProm = getOper.getDibblerData(updateData["docker-name"]);
                } else if(updateData.type == "status") {
                    var cmd = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'ps -aux |grep dibbler'";
                    resProm = getOper.getServerStatus("dibbler",cmd,"start");
                } else if(updateData.type == "leases") {
                    res.jsonp({"state":"No Lease information available"});
                }
            } else {
                res.jsonp({"state":"Parameter is wrong."});
            }
            if(resProm !== undefined && resProm !== "") {
                if(resProm.then !== undefined) {
                    resProm.then(function(data){
                        console.log(data);
                        res.jsonp(data)
                    })
                }
            } else {
                if(updateData.operation !== undefined) {
                    res.jsonp({"message":"Request parameter"+ updateData.operation +"operation or docker-name error,please check method!"});
                } else {
                    res.jsonp({"state":"Docker is not running or IPv6 is not enabled"});
                }
            }
        }
    })
})

server.post('/ipoe/dibbler-server',function(req,res){
    var updateData = "";
    req.on('data', function (data) {
        console.log(data.toString());
        updateData = data.toString();
        updateData = getRequestData.getRequestData(updateData);
    })
    req.on('end',function(){
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter operation or docker name error,please check method!"});
        } else {
            var resProm ="";
            if(updateData.operation  !== "" && updateData["docker-name"] !== "") {
                console.log("enter radvd " + updateData.operation + " operation");
                resProm =restartOper.dibblerOperation(updateData);
            }
            if(resProm !== undefined && resProm !== "") {
                if(resProm.then !== undefined) {
                    resProm.then(function(data){
                        console.log(data);
                        res.jsonp(data)
                    })
                }else{
                    res.jsonp({"state":"success"});
                }
            } else {
                if(updateData.type !== undefined) {
                    res.jsonp({"message":"Request parameter"+ updateData.type +"operation or docker-name error,please check method!"});
                } else {
                    res.jsonp({"state":"Docker is not running or IPv6 is not enabled"});
                }
            }
        }
    })
})

server.get('/ipoe/bind9',function(req,res) {
    var updateData = "";
    req.on('data', function (data) {
        var reqData = data.toString();
        updateData = getRequestData.getDhcp6sReqData(reqData);
    })
    req.on('end',function(){
        console.log(updateData);
        if(updateData == "") {
            res.jsonp({"message":"Request parameter error."});
        } else {
            var resProm ="";
            if(updateData.operation  !== undefined) {
                console.log("enter bind9 " + updateData.operation + " operation,");
                resProm =restartOper.bind9Operation(updateData);
            }
            if(resProm !== undefined && resProm !== "") {
                if(resProm.then !== undefined) {
                    resProm.then(function(data){
                        console.log(data);
                        res.jsonp(data)
                    })
                }else{
                    res.jsonp({"state":"success"});
                }
            } else {
                res.jsonp({"state":false});
            }
        }
    })
})


// Use default router
server.use(router)
server.listen(port,'::', function () {
    console.log("REST API is running on "+port +" port")
})
