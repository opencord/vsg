/**
 * File:         getDhcp6Vars.js
 * Contents:     get data from /cord/ipoe-setup/wide-dhcp6.vars
 */
var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
module.exports= {
    getDhcp6Variables: function(content) {
        console.log("enter getDhcp6 Vars!");
        var result = "{";
        var str = content.split('\n');
        var flagInitObj = true;
        var ipv6_sub_perfix = null;
        var ipv6_perfix = null;
        var length =  str.length;
        var cord_env=true;
        if(length > 0) {
            for (var i = 0; i < length - 1; i++) {
                var strr='';
                if(str[i].match("#") || str[i].match("IPOE_SERVER_MGMT_IP=")) {
                    continue;
                } else {
                    if(str[i].match("=")) {
                        console.log(str[i]);
                        var spistr = str[i].split("=");
                        if(str[i].match("CORD_ENV=")) {
                            cord_env = Boolean(spistr[1]);
                            console.log("cord_env: "+cord_env);
                        }
                        if(str[i].match("if")) {
                            console.log(cord_env);
                            if(cord_env) {
                                console.log("eneter true");
                                var ip = str[i+1].split("=");
                                strr += ',\"' + ip[0].replace(/(^\s*)|(\s*$)/g, "") + '\":' + ip[1];
                                var nameServer = str[i+2].split("=");
                                strr += ',\"' + nameServer[0].replace(/(^\s*)|(\s*$)/g, "") + '\":' + nameServer[1];
                                console.log(strr);
                                result += strr;
                                break;
                            } else {
                                i= i+2;
                                continue;
                            }
                        }
                        if(str[i].match("IPOE_IPV6_SUB_PREFIX=")) {
                            ipv6_sub_perfix = spistr[1].substring(1,spistr[1].length-1);
                        }
                        if(str[i].match("IPOE_IPV6_PREFIX=")) {
                            var temp = spistr[1].split(":");
                            ipv6_perfix = ipv6_sub_perfix + ":"+temp[1].substring(0,temp[1].length-1);
                        }
                        if(ipv6_sub_perfix !==null) {
                            if(str[i].indexOf("$IPOE_IPV6_SUB_PREFIX")>-1) {
                                var newstr = str[i].replace("$IPOE_IPV6_SUB_PREFIX",ipv6_sub_perfix);
                                spistr = newstr.split("=");
                            }
                        }
                        if(ipv6_perfix !== null) {
                            if(str[i].indexOf("$IPOE_IPV6_PREFIX")>-1) {
                               var newstr = str[i].replace("$IPOE_IPV6_PREFIX",ipv6_perfix);
                                spistr = newstr.split("=");
                            }
                        }
                        if(flagInitObj) {
                            if(spistr[0] == "secret_key") {
                                if (spistr[2] !== undefined) {
                                    strr += '\"' + spistr[0].replace(/(^\s*)|(\s*$)/g, "")+ '\":'+spistr[1] +spistr[2];
                                } else {
                                    strr += '\"' + spistr[0].replace(/(^\s*)|(\s*$)/g, "") + '\":'+spistr[1];
                                }

                            }   else if(spistr[0].match("DHCP6S_IPOE_INTF") || spistr[0].match("DHCP6C_WAN_INTF")
                                || spistr[0].match("DHCP6C_LAN_INTF")){
                                strr += '\"' + spistr[0] + '\":\"'+spistr[1] + "\"";
                            }  else {
                                strr += '\"' + spistr[0].replace(/(^\s*)|(\s*$)/g, "") + '\":'+spistr[1];
                            }
                            flagInitObj = false;
                        } else {
                            if(spistr[0] == "secret_key") {
                                if (spistr[2] !== undefined) {
                                    strr += ',\"' + spistr[0].replace(/(^\s*)|(\s*$)/g, "")+ '\":'+spistr[1] +spistr[2];
                                } else {
                                    strr += ',\"' + spistr[0].replace(/(^\s*)|(\s*$)/g, "") + '\":'+spistr[1];
                                }
                            }  else if(spistr[0].match("DHCP6S_IPOE_INTF") || spistr[0].match("DHCP6C_WAN_INTF")
                                || spistr[0].match("DHCP6C_LAN_INTF")){
                                strr += ',\"' + spistr[0] + '\":\"'+spistr[1] + "\"";
                            }  else {
                                strr += ',\"' + spistr[0].replace(/(^\s*)|(\s*$)/g, "") + '\":' + spistr[1];
                            }
                        }
                    }
                }
                result += strr;
            }
        }
        result += '}';
        console.log("result:"+result);
        return result;
    }
}




