/**
 * File:         readFile.js
 * Contents:     read configuration files
 */

var fs=require('fs');
var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
var tmpkeyinfo = {};
var tmphost = {};
module.exports= {
    updateDhcp6cField: function(line,updateData) {
        if(line.match("#") !== null) {
            if(line.match("#send") !== null ) {
                line = commonOper.modifiedDhcp6cSend(line,"authentication",updateData);
            } else if(line.match("#request") !== null) {
                var spistr = commonOper.rep_spi_space(line);
                line = compareDhcp6cRequest(line,spistr,updateData);
            }
            return line;
        } else if(line.match("realm") !== null || line.match("keyid") !== null
            || line.match("secret") !== null) {
            var spistr = commonOper.rep_spi_space(line);
            if(line.match("vcpe-secret-auth;")) {
                line = commonOper.modifiedDhcp6cSend(line,"authentication",updateData);
                return line;
            }
            line = commonOper.modifiedDhcp6Keyinfo(line,spistr,updateData,'keyinfo');
        } else if ( line.match("domain-name-servers") !== null ||
            line.match("domain-name") !== null ||
            line.match("ntp-servers") !== null) {
            var spistr = commonOper.rep_spi_space(line);
             line = compareDhcp6cRequest (line,spistr,updateData);
        } else if(line.match("sla-id")) {
            if(updateData["sla-id"] !== undefined) {
                line = "                " + "sla-id" + " " + updateData["sla-id"] + ';';
            }
        }
        return line;
    },
    updateDhcp6sField: function(line,updateData) {
        if(line.match("#") !== null) {
            return line;
        }else if((line.match("realm") !== null || line.match("keyid") !== null
            || line.match("secret") !== null) ) {
            var spistr = commonOper.rep_spi_space(line);
            if (line.match("keyinfo")) {
                if(updateData["keyinfo"] !== undefined) {
                    tmpkeyinfo = {};
                    for (var i = 0; i<updateData["keyinfo"].length;i++) {
                        if(updateData["keyinfo"][i].name == spistr[1]) {
                            tmpkeyinfo = {"keyinfo":updateData["keyinfo"][i].value};
                        }
                    }
                }
                return line;
            } else {
                line = commonOper.modifiedDhcp6Keyinfo(line,spistr,tmpkeyinfo,'keyinfo');
            }
        } else if(line.match("option") !== null) {
            var spistr = commonOper.rep_spi_space(line);
            if(spistr[1] == "domain-name-servers" ) {
                line =commonOper.modifiedDhcp6Option(line,spistr,updateData,"domain-name-servers");
            }
            if(spistr[1] == "domain-name") {
                line =commonOper.modifiedDhcp6Option(line,spistr,updateData,"domain-name");
            }
            if(spistr[1] == "ntp-servers") {
                line =commonOper.modifiedDhcp6Option(line,spistr,updateData,"ntp-servers");
            }

        } else  if (line.match("host")) {
            var spistr = commonOper.rep_spi_space(line);
            if (updateData["host"] !== undefined) {
                tmphost = {};
                for (var i = 0; i < updateData["host"].length; i++) {
                    if (updateData["host"][i].name == spistr[1]) {
                        tmphost = {"host": updateData["host"][i].value};
                    }
                }
            }
            return line;
        } else if(line.match("duid") !== null || line.match("prefix") !== null
            || line.match("address") !== null) {
            var spistr = commonOper.rep_spi_space(line);
            if(spistr[0] == "duid") {
                if( tmphost["host"] !==undefined && tmphost["host"]["duid"] !== undefined ) {
                    line = "        duid" + " " + tmphost["host"]["duid"] +";";
                }
            } else if(spistr[0] == "prefix" || spistr[0] == "address") {
                if(line.match("address-pool")) {
                    return line;
                }
                line = commonOper.modifiedDhcp6Host(line,spistr,tmphost,spistr[0]);
            }
        } else if(line.match("range") !== null) {
            if(updateData["pool"] == undefined) {
                return line;
            }
            var spistr = commonOper.rep_spi_space(line);
            if(updateData["pool"].start !== undefined  && updateData["pool"].end !== undefined) {
                console.log("enter start and end :" + updateData["pool"].end);
                line = "        range "+ updateData["pool"].start + " to " + updateData["pool"].end +";";
            } else{
                if(updateData["pool"].start !== undefined ) {
                    line = "        range "+ updateData["pool"].start + " to " + spistr[3];
                } else if(updateData["pool"].end !== undefined) {
                    console.log("enter  end :" + updateData["pool"].end);
                    line = "        range "+ spistr[1] + " to " + updateData["pool"].end +";";
                    console.log("line:"+line);
                }
            }
        }
        return line;
    },
    createDhcp6sField: function(line,createData) {
        if(line.match("#") !== null) {
            return line;
        } else if (line.match("keyinfo")) {
            line = commonOper.createDhcp6sKeyinfo(line,createData);
        } else if(line.match("host")) {
            line = commonOper.createDhcp6sHost(line,createData);
        }
        return line;
    },
    createDhcp6cField: function(line,createData) {
        if(line.match("#") !== null) {
            return line;
        } else if (line.match("keyinfo")) {
            var db=JSON.parse(fs.readFileSync("db.json"));
            var keyid = createData.ctag - db["onu"].ctag;
            line = "keyinfo vcpe-" +createData.ctag + "-secret-key {" + "\n";
            line += "        realm " + '\"fj-ipoe-' + createData.ctag+ '.net\";' + "\n";
            line += "        keyid " + (keyid+1) +";" + "\n";
            line += "        secret " +"\"ZmotaXBvZS1wYXNzd2Q=\";" + "\n";
            line += "};" +"\n";
        } else if(line.match("sla-id")) {
            line = "                " + "sla-id" + " " + createData.ctag + ';';
        }
        return line;
    },
    updateDibblerServer:function(line,updateData) {
        if(line.match("iface") && updateData.interface !== undefined) {
            line = "iface " + updateData.interface + " {";
        }
        if(line.match("dns-server") && updateData["dns-server"] !== undefined) {
            line = "option dns-server " + updateData["dns-server"];
        }
        if(line.match("domain") && updateData["domain"] !== undefined) {
            line = "option domain " + updateData["domain"];
        }
        if(line.match("ntp-server") && updateData["ntp-server"] !== undefined) {
            line = "option ntp-server " + updateData["ntp-server"];
        }
        return line;
    },
    updateRadvdConf:function(line,updateData) {
        if(line.match("interface")  && updateData.interface !== undefined) {
            line = "interface   " + updateData.interface;
        }
        if(line.match("prefix")  && updateData["prefix"] !== undefined) {
            line = "prefix  " + updateData["prefix"];
        }
        console.log(line);
        return line;
    },
    updatevars:function(line,updateData) {
        if(line.match("#") !== null) {
            return line;
        } else {
            if(line.match("IPOE_IPV6_SUB_PREFIX=") && updateData["IPOE_IPV6_SUB_PREFIX"] !== undefined) {
                line = "IPOE_IPV6_SUB_PREFIX="+"\""+ updateData["IPOE_IPV6_SUB_PREFIX"] +"\"";
            }
            if(line.match("IPOE_IPV6_PREFIX=") && updateData["IPOE_IPV6_PREFIX"] !== undefined) {
                var perfix = updateData["IPOE_IPV6_PREFIX"].split(":");
                line = "IPOE_IPV6_PREFIX="+ "\"" +"$IPOE_IPV6_SUB_PREFIX:"+perfix[perfix.length-1]+"\"";
            }
            if(line.match("dom_name=") && updateData["dom_name"] !== undefined) {
                line = "dom_name="+"\"" +updateData["dom_name"]+"\"";
            }
            if(line.match("domain_name_servers=") && updateData["domain_name_servers"] !== undefined) {
                line = "domain_name_servers="+"\"" +updateData["domain_name_servers"]+"\"";
            }
            if(line.match("ntp_servers=") && updateData["ntp_servers"] !== undefined) {
                var spi = updateData["ntp_servers"].split("::");
                line = "ntp_servers="+"\""+"$IPOE_IPV6_PREFIX::"+spi[1]+"\"";
            }
            if(line.match("sip_server_address=") && updateData["sip_server_address"] !== undefined) {
                var spi = updateData["sip_server_address"].split("::");
                line = "sip_server_address="+"\""+"$IPOE_IPV6_PREFIX::"+spi[1]+"\"";
            }
            if(line.match("secret_key=") && updateData["secret_key"] !== undefined) {
                line = "secret_key="+"\""+updateData["secret_key"]+"\"";
            }
            /*if(line.match("DHCP6S_IPOE_INTF=") && updateData["DHCP6S_IPOE_INTF"] != undefined) {
                line = "DHCP6S_IPOE_INTF="+updateData["DHCP6S_IPOE_INTF"];
            }*/
            if(line.match("IPOE_IPV6_ADDR_LOW=") && updateData["IPOE_IPV6_ADDR_LOW"] !== undefined) {
                line = "IPOE_IPV6_ADDR_LOW="+updateData["IPOE_IPV6_ADDR_LOW"];
            }
            if(line.match("IPOE_IPV6_ADDR_HIGH=") && updateData["IPOE_IPV6_ADDR_HIGH"] !== undefined) {
                line = "IPOE_IPV6_ADDR_HIGH="+updateData["IPOE_IPV6_ADDR_HIGH"];
            }
            if(line.match("DUID_PREFIX=") && updateData["DUID_PREFIX"] !== undefined) {
                line = "DUID_PREFIX="+"\""+updateData["DUID_PREFIX"]+"\"";
            }
            if(line.match("MAC_PREFIX=") && updateData["MAC_PREFIX"] !== undefined) {
                line = "MAC_PREFIX="+"\""+updateData["MAC_PREFIX"]+"\"";
            }
            if(line.match("VCPE_DOCKER_NAMES=") && updateData["VCPE_DOCKER_NAMES"] !== undefined) {
                var newName = updateData["VCPE_DOCKER_NAMES"];
                var oldName = line.split("=");
                oldName[1] = oldName[1].substring(1,(oldName[1].length-1));
                var dockerNames = commonOper.updateVpceDockerName(oldName[1],newName);
                line = "VCPE_DOCKER_NAMES=" +"\""+dockerNames+"\"";
            }
            /*if(line.match("DHCP6C_WAN_INTF=") && updateData["DHCP6C_WAN_INTF"] !== undefined) {
                line = "DHCP6C_WAN_INTF="+updateData["DHCP6C_WAN_INTF"];
            }
            if(line.match("DHCP6C_LAN_INTF=") && updateData["DHCP6C_LAN_INTF"] !== undefined) {
                line = "DHCP6C_LAN_INTF="+updateData["DHCP6C_LAN_INTF"];
            }*/
            if(line.match("DHCP6C_REQUEST_PARAMS=") && updateData["DHCP6C_REQUEST_PARAMS"] !== undefined) {
                var newParams = updateData["DHCP6C_REQUEST_PARAMS"];
                var oldParams = line.split("=");
                oldParams[1] = oldParams[1].substring(1,(oldParams[1].length-1));
                var requestParams = commonOper.updateRequestParams(oldParams[1],newParams);
                line = "DHCP6C_REQUEST_PARAMS=" +"\""+requestParams+"\"";
            }
            if(line.match("TAYGA_IPV6_PREFIX=") && updateData["TAYGA_IPV6_PREFIX"] !== undefined) {
                line = "TAYGA_IPV6_PREFIX="+"\""+updateData["TAYGA_IPV6_PREFIX"]+"\"";
            }
            if(line.match("TAYGA_ROUTER_IPV6_IP=") && updateData["TAYGA_ROUTER_IPV6_IP"] !== undefined) {
                line = "TAYGA_ROUTER_IPV6_IP="+"\""+updateData["TAYGA_ROUTER_IPV6_IP"]+"\"";
            }
            if(line.match("TAYGA_ROUTER_IPV4_IP=") && updateData["TAYGA_ROUTER_IPV4_IP"] !== undefined) {
                line = "TAYGA_ROUTER_IPV4_IP="+"\""+updateData["TAYGA_ROUTER_IPV4_IP"]+"\"";
            }
            if(line.match("TAYGA_POOL=") && updateData["TAYGA_POOL"] !== undefined) {
                line = "TAYGA_POOL="+"\""+updateData["TAYGA_POOL"]+"\"";
            }
            if(line.match("NAMESERVER=") && updateData["NAMESERVER"] !== undefined) {
                line = "NAMESERVER="+"\""+updateData["NAMESERVER"]+"\"";
            }
        }
        return line;
    }
}

function compareDhcp6cRequest (line,spistr,updateData) {
    if(spistr[1] == "domain-name-servers;" ) {
        line = commonOper.modifiedDhcp6cRequest(line,"domain-name-servers;",updateData);
    }
    if(spistr[1] == "domain-name;") {
        line = commonOper.modifiedDhcp6cRequest(line,"domain-name;",updateData);
    }
    if(spistr[1] == "ntp-servers;") {
        line = commonOper.modifiedDhcp6cRequest(line,"ntp-servers;",updateData);
    }
    return line;
}
