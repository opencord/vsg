/**
 * File:         getConfData.js
 * Contents:     get data from configuration files
 */

var Promise=require('bluebird');
var execAsync=Promise.promisify(require('child_process').exec);
var fs=require('fs');
var __dirname = "/usr/local/lib/node_modules";
var getDhcp6sOper = require(__dirname + '/getDhcp6s');
var getDhcp6cOper = require(__dirname + '/getDhcp6c');
var getDibblerOper = require(__dirname + '/getDibbler');
var getDhcp6VarsOper = require(__dirname + '/getDhcp6Vars');
var getRadvdOper = require(__dirname + '/getRadvd');
var getLeaseinfoOper = require(__dirname + '/getLeaseInfo');
var commonOper = require(__dirname + '/common');
module.exports={
    getDhcp6sData: function() {
        console.log("enter getDhcp6sData ");
        return execAsync("sudo cat /etc/wide-dhcpv6/dhcp6s.conf").then(function(content){
            var result = getDhcp6sOper.getDhcp6s(content);
            console.log("result:"+result);
            var respData = eval('(' +result +')');
            return respData
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"dhcp6s":"No dhcp6s.conf."};
        });
    },//get Dhcp6s Data
    getDhcp6cData: function (stag,ctag,dockername) {
        console.log("enter getDhcp6cData");
        console.log("dockername: "+ dockername);
        var cmd = "docker exec -i "+ dockername + " /bin/bash -c 'cat /etc/wide-dhcpv6/dhcp6c.conf'";
        console.log("getDhcp6cData command: "+cmd);
        return execAsync(cmd).then(function(content){
            return getDhcp6cOper.getDhcp6c(content,stag,ctag,dockername);
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"dhcp6c":"Docker is not running or IPv6 is not enabled"};
        });
    },//get Dhcp6c Data
    getDibblerData:function(dockername) {
        console.log("enter getDibblerData");
        console.log("dockername: "+ dockername);
        var cmd = "docker exec -i "+ dockername + " /bin/bash -c 'cat /etc/dibbler/server.conf'";
        console.log("getDibblerData command: "+cmd);
        return execAsync(cmd).then(function(content){
            var result = getDibblerOper.getDibblerServer(content)
            var jsonSta = eval('(' +result +')')
            return jsonSta
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"server":"Docker does not exist or IPv6 is not enabled."};
        });
    },
    getDhcpv6cStatus:function(name,command,key) {
        return execAsync(command).then(function(content){
            console.log("command:"+command+"key:"+key + "name :"+name);
            var result = getDhcp6cOper.getdhcp6cStatus(content,key,name);
            var jsonSta = eval('(' +result +')');
            return jsonSta;
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"status":"Docker does not exist !"};
        });
    },
    getServerStatus:function(name,command,key) {
        return execAsync(command).then(function(content){
            console.log("command:"+command+"key:"+key + "name :"+name);
            var result = getDibblerOper.getStatus(content,key,name);
            var jsonSta = eval('(' +result +')');
            return jsonSta;
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"status":"Docker does not exist !"};
        });
    },
    getRadvdServerStatus:function(command) {
        return execAsync(command).then(function(content){
            var result = getRadvdOper.getRadvdStatus(content);
            var jsonSta = eval('(' +result +')');
            return jsonSta;
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"status":"Docker does not exist !"};
        });
    },
    getRadvdData:function(dockername) {
        var cmd = "docker exec -i "+ dockername + " /bin/bash -c 'cat /etc/radvd.conf'";
        console.log("getRadvdData command: "+cmd);
        return execAsync(cmd).then(function(content){
            var result = getRadvdOper.getRadvd(content);
            var jsonSta = eval('(' +result +')');
            return jsonSta
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"status":"Docker does not exist or IPv6 is not enabled."};
        });
    },
    getDhcp6VarsData:function(wideDhcp6cVarPath) {
        console.log("enter getDhcp6VarsData");
        return execAsync("cat "+ wideDhcp6cVarPath).then(function(content){
            var result = getDhcp6VarsOper.getDhcp6Variables(content);
            var jsonSta = eval('(' +result +')');
            return jsonSta
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"server":"No dhcp6s.conf."};
        });
    },
    getDhcp6cLeaseInfo: function(dockername) {
        console.log("getDhcp6cLeaseInfo dockername: "+ dockername);
        var cmd = "docker exec -i "+ dockername + " /bin/bash -c 'cat /var/lib/dhcpv6/client.lease'";
        return execAsync(cmd).then(function(content){
            console.log(content);
            var result = getLeaseinfoOper.getDhcp6cLease(content);
            var jsonSta = eval('(' +result +')')
            return jsonSta
        }).catch(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"server":"Docker does not exist or IPv6 is not enabled."};
        });
    },
    getDhcp6sLeaseInfo: function() {
    console.log("get Dhcp6s Lease Info");
    var cmd = "sudo cat /var/lib/dhcpv6/server6.leases";
    return execAsync(cmd).then(function(content){
        console.log(content);
        var result = getLeaseinfoOper.getDhcp6sLease(content);
        var jsonSta = eval('(' +result +')')
        return jsonSta
    }).catch(function(error){
        var errorResp = commonOper.handleError(error);
        if(errorResp.errorMessage !== null) {
            console.log(errorResp.errorMessage);
        }
        return {"state":"No Lease information available."};
    });
}
}