/**
 * File:         getRequestPar.js
 * Contents:     get request parameters for docker
 */

module.exports={
    getRequestData:function(updateData) {
        var data = "";
        if(updateData.match("&")) {
            var tmpstr = "";
            if(updateData.match("{") && updateData.match("}")) {
                tmpstr = updateData.substring(1,updateData.length-1).split("&");
            } else {
                tmpstr = updateData.split("&");
            }
            var typevalue = "";
            var dockername = "";
            var operValue = "";
            for(var i= 0;i<tmpstr.length;i++) {
                var str = tmpstr[i].split("=");
                if(str[0] == "type") {
                    typevalue = str[1];
                }
                if(str[0] == "docker-name") {
                    dockername = str[1];
                }
                if(str[0] == "operation") {
                    operValue = str[1];
                }
            }
            data = {"type":typevalue,"operation":operValue,"docker-name":dockername};
        }
        return data;
    },
    getDhcp6sReqData:function(reqData) {
        var updateData = "";
        if(reqData.match("&")) {
            return updateData;
        } else if(reqData.match("=")) {
            var str = "";
            if(reqData.match("{") && reqData.match("}")) {
                str = reqData.substring(1,reqData.length-1).split("=");
            } else {
                str = reqData.split("=");
            }
            if(str !== "") {
                if(str[0] == "type") {
                    updateData = {"type":str[1]};
                } else if(str[0] == "operation") {
                    updateData = {"operation": str[1]};
                }
            }
        }
        return updateData;
    },
    getSystemVarsReqData:function(reqData) {
        var result = "{";
        var flagInitObj = true;
        if(reqData.match("&")) {
            var str = "";
            if(reqData.match("{") && reqData.match("}")) {
                return "";
            } else {
                str = reqData.split("&");
            }
            if(str.length>0) {
                for (var i = 0; i < str.length; i++) {
                    var strr = '';
                    console.log("str:" + str[i]);
                    var spistr = str[i].split("=");
                    if (flagInitObj) {
                        strr += '\"' + spistr[0] + '\":\"' + spistr[1] + '\"';
                        flagInitObj = false;
                    } else {
                        strr += ',\"' + spistr[0] + '\":\"' + spistr[1] + '\"';
                    }
                    result += strr;
                }
            }
        } else if(reqData.match("=")) {
            var spistr = reqData.split("=");
            result += '\"' + spistr[0] + '\":\"' + spistr[1] + '\"';
        }
        result += '}';
        console.log("result:"+result);
        var jsonSta = eval('(' +result +')')
        return jsonSta;
    }
}
