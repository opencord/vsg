/**
 * File:         updateConf.js
 * Contents:     update configuration files
 */

var Promise=require('bluebird')
var execAsync=Promise.promisify(require('child_process').exec)
var fs=require('fs');
var lineReader = require('line-reader');
var __dirname = "/usr/local/lib/node_modules";
var updateOper = require(__dirname + '/readFile');
var commonOper = require(__dirname + '/common');

module.exports={
    updateVariables:function(file,updateData) {
        console.log("file path:"+ file);
        var resultBuffer = '';
        var rsp = {};
        rsp = lineReader.eachLine(file, function(line, last) {
            var resdata ;
            resdata = updateOper.updatevars(line,updateData);
            resultBuffer += resdata;
            resultBuffer += "\n";
            if(last === true && resultBuffer.length !== 0 ) {
                fs.writeFile(file, resultBuffer ,function(err) {
                    if (err) {
                        rsp = {"state":false};
                        throw err;
                    } else {
                        console.log("Update wide-dhcp6.vars success!");
                        rsp = {"state":true};
                        return rsp;
                    }
                });
            }
            return rsp;
        });
        return rsp;
    },
    updateDhcp6c: function(file,updateData,method) {
        var resultBuffer = '';
        var rsp = {};
        rsp = lineReader.eachLine(file, function(line, last) {
            var resdata ;
            if(method == "update") {
                resdata = updateOper.updateDhcp6cField(line,updateData);
            } else {
                resdata = updateOper.createDhcp6cField(line,updateData);
            }
            resultBuffer += resdata;
            resultBuffer += "\n";
            if(last === true && resultBuffer.length !== 0 ) {
                fs.writeFile('/etc/wide-dhcpv6/dhcp6c.conf', resultBuffer, function(err) {
                    if (err) {
                        rsp = {"state":false};
                        throw err;
                    } else {
                        console.log("Update dhcp6c.conf success!");
                        rsp = {"state":true};
                        return rsp;
                    }
                });
            }
            return rsp;
        });
        return rsp;
    },
    updateDhcp6s: function(file,updateData,method) {
        var resultBuffer = '';
        var rsp = {};
        rsp = lineReader.eachLine(file, function(line, last) {
            var resdata ;
            if(method == "update") {
                resdata = updateOper.updateDhcp6sField(line,updateData);
            } else {
                resdata = updateOper.createDhcp6sField(line,updateData);
            }
            resultBuffer += resdata;
            resultBuffer += "\n";
            if(last === true && resultBuffer.length !== 0 ) {
                fs.writeFile('/etc/wide-dhcpv6/dhcp6s.conf', resultBuffer, function(err) {
                    if (err) {
                        rsp = {"state":false};
                        throw err;
                    } else {
                        console.log("Update dhcp6s.conf success!");
                        rsp = {"state":true};
                        return rsp;
                    }
                });
            }
            return rsp;
        });
        return rsp;
    },
    updateDibbler:function(file,updateData) {
        var resultBuffer = '';
        var rsp = {};
        rsp = lineReader.eachLine(file, function(line, last) {
            var resdata ;
            resdata = updateOper.updateDibblerServer(line,updateData);
            resultBuffer += resdata;
            resultBuffer += "\n";
            if(last === true && resultBuffer.length !== 0 ) {
                fs.writeFile('/etc/dibbler/server.conf', resultBuffer, function(err) {
                    if (err) {
                        rsp = {"state":false};
                        throw err;
                    } else {
                        console.log("Update dibbler server.conf success!");
                        rsp = {"state":true};
                        return rsp;
                    }
                });
            }
            return rsp;
        });
        return rsp;
    },
    updateRadvd:function(file,updateData) {
        var resultBuffer = '';
        var rsp = {};
        rsp = lineReader.eachLine(file, function(line, last) {
            var resdata ;
            resdata = updateOper.updateRadvdConf(line,updateData);
            resultBuffer += resdata;
            resultBuffer += "\n";
            if(last === true && resultBuffer.length !== 0 ) {
                fs.writeFile('/etc/radvd.conf', resultBuffer, function(err) {
                    if (err) {
                        rsp = {"state":false};
                        throw err;
                    } else {
                        console.log("Update radvd.conf success!");
                        rsp = {"state":true};
                        return rsp;
                    }
                });
            }
            return rsp;
        });
        return rsp;
    }
}