/**
 * File:         stopAllServer.js
 * Contents:     stop all server process
 */

var __dirname = "/usr/local/lib/node_modules";
var restartOper = require(__dirname + '/restartServer');

module.exports={
    stopAll:function(updateData) {
        console.log("enter stopAll");
        console.log(updateData);
        var resProm;
        restartOper.dhcp6cOperation(updateData);
        setTimeout(function(){
            restartOper.radvdOperation(updateData);
        },1000*1);
        setTimeout(function(){
            resProm =restartOper.dibblerOperation(updateData);
        },1000*2);
        if(resProm !== undefined) {
            resProm.then(function(data){
                console.log(data);
                return data;
            })
        } else {
            return {"state":"Docker is not running or IPv6 is not enabled"};
        }
    }
}
