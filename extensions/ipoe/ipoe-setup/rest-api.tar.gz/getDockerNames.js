/**
 * File:         GetDockerNames.js
 * Contents:     get all docker name in vsg-server
 */

var Promise=require('bluebird');
var execAsync=Promise.promisify(require('child_process').exec);
var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
var stopAllOper = require(__dirname + '/stopAllServer');
var startAllOper = require(__dirname + '/startAllServer');
var restartOper = require(__dirname + '/restartServer');
var stopOper = require(__dirname + '/stopServer');

module.exports={
    getAllDockerNames:function(updateData) {
        var names =[];
        return execAsync("docker ps").then(function(content){
            var str = content.split('\n');
            if(str.length>0) {
                for (var i = 0; i < str.length - 1; i++) {
                    if(str[i].match("vcpe-")) {
                        var ss = str[i].replace(/\s+/g, ' ');
                        var spistr = commonOper.rep_spi_space(ss);
                        var length = spistr.length;
                        names.push(spistr[length-1]);
                    }
                }
            }
            console.log(names);
            for (var i =0; i< names.length;i++) {
                var  data = {"operation":updateData.operation,"docker-name":names[i]};
                console.log(data);
                if(updateData.operation == "stop") {
                    stopAllOper.stopAll(data);
                } else if (updateData.operation == "start"){
                    restartOper.dhcp6cOperation(data);
                } else if(updateData.operation == "restart") {
                    var stopdata = {"operation":"stop","docker-name":names[i]};
                    console.log("stop === ")
                    console.log(stopdata);
                    resProm = stopAllOper.stopAll(stopdata);
                    setTimeout(function(){
                        for (var i =0; i< names.length;i++) {
                            var startdata = {"operation":"start","docker-name":names[i]};
                            console.log("enter timeout start === ")
                            console.log(startdata);
                            restartOper.dhcp6cOperation(startdata);
                        }

                    },1000*5);
                } else if(updateData.operation == "disable") {
                    resProm = stopOper.stopDocker(data);
                } else if(updateData.operation == "enable") {
                    resProm = stopOper.restartDocker(data);
                }
            }
            return {"state":"success"};
        });
    }
}
