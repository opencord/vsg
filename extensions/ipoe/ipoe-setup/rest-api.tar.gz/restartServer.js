/**
 * File:         restartServer.js
 * Contents:     restart all server
 */

var Promise=require('bluebird')
var execAsync=Promise.promisify(require('child_process').exec);
var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
var stopOper = require(__dirname + '/stopServer');

module.exports={
    restart:function(command,key,restartCmd,msg,name,cmd_kill) {
        return execAsync(command).then(function(content){
            var str = content.split('\n');
            if(str.length>0) {
                var flag = true;
                for (var i = 0; i < str.length - 1; i++) {
                    if(str[i].match(key)) {
                        console.log(str[i]);
                        var ss = str[i].replace(/\s+/g, ' ');
                        var spistr = commonOper.rep_spi_space(ss);
                        console.log(spistr[1]);
                        console.log(ss);
                        if(flag) {
                            flag = false;
                            if(name == "dhcp6s") {
                                execAsync("sudo kill -9  " + parseInt(spistr[1])).then(function(){
                                    execAsync(restartCmd).then(function(err){
                                        console.log(msg);
                                        if (err && name == "radvd") reject(err);
                                        return {"status":msg};
                                    });
                                });
                            } else {
                                execAsync(cmd_kill + parseInt(spistr[1])).then(function(){
                                    execAsync(restartCmd).then(function(err){
                                        console.log(msg);
                                        if (err && name == "radvd") reject(err);
                                        return {"status":msg};
                                    });
                                });
                            }
                        }
                    } else {
                        execAsync(restartCmd).then(function(err){
                            console.log(msg);
                            if (err && name == "radvd") reject(err);
                            return {"status":msg};
                        });
                    }
                }
            }
        });
        return {"status":msg};
    },
    dhcp6sOperation:function(updateData) {
        var cmd = "";
        if(updateData.operation == "start") {
            cmd = "sudo /usr/sbin/dhcp6s -D -k /dev/null -P /var/run/dhcp6s.eth1.pid eth1";
        } else if(updateData.operation == "stop") {
            cmd = "sudo /etc/init.d/wide-dhcpv6-server stop"
        } else if(updateData.operation == "restart"){
            cmd = "sudo /etc/init.d/wide-dhcpv6-server restart"
        } else {
            return {"status":"Not supported " + updateData.operation +" operation!"};
        }
        console.log("cmd: "+cmd);
        return execAsync(cmd).then(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"status":"Dhcp6s " + updateData.operation +" success!"};
        });
    },
    dhcp6cOperation:function(updateData) {
        console.log("data: "+updateData);
        var cmd = "";
        var cmd_interface = "";
        console.log("enter dockername :"+updateData["docker-name"] + " and "+updateData["operation"]+" operation");
        if(updateData.operation == "start") {
           cmd = "/tmp/reinit-dhcp6c.sh  " + updateData["docker-name"] + "  wide-dhcp6.vars";
            console.log("dhcp6c start cmd: "+cmd);
            return execAsync(cmd).then(function(error){
                var errorResp = commonOper.handleError(error);
                if(errorResp.errorMessage !== null) {
                    console.log(errorResp.errorMessage);
                }
             return {"status":"Dhcp6c " + updateData.operation +" success!"};
             });

            /*cmd_interface ="sudo docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'ifconfig eth2 up'";
            console.log("cmd_interface: "+cmd_interface);
            cmd = "sudo docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'dhcp6c  -c /etc/wide-dhcpv6/dhcp6c.conf eth2'";
            console.log("cmd: "+cmd);
            return execAsync(cmd_interface).then(function(err){
                return execAsync(cmd).then(function(err){
                    return {"status":"Dhcp6c " + updateData.operation +" success!"};
                });
            });*/
        } else if(updateData.operation == "stop") {
            cmd = "sudo docker exec -i "+ updateData["docker-name"] + " /bin/bash -c '/etc/init.d/wide-dhcpv6-client stop'";
            cmd_interface ="sudo docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'ifconfig eth2 down'";
            console.log("dhcp6c command: "+cmd);
            console.log("interface command: "+cmd_interface);
             /*return execAsync(cmd).then(function(err){
             return {"status":"Dhcp6c " + updateData.operation +" success!"};
             });*/
            return execAsync(cmd).then(function(error){
                var errorResp = commonOper.handleError(error);
                if(errorResp.errorMessage !== null) {
                    console.log(errorResp.errorMessage);
                }
                return execAsync(cmd_interface).then(function(error){
                    var errorResp = commonOper.handleError(error);
                    if(errorResp.errorMessage !== null) {
                        console.log(errorResp.errorMessage);
                    }
                    return {"status":"Dhcp6c " + updateData.operation +" success!"};
                });
            });
        }
    },
    bind9Operation:function(updateData) {
        var cmd = "sudo service bind9 restart";
        return execAsync(cmd).then(function(error){
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return {"status":"bind9 " + updateData.operation +" success!"};
        });
    },
    radvdOperation:function(updateData) {
        console.log("enter radvd " + updateData.operation + " operation");
        var cmd = "";
        if(updateData.operation == "start") {
            console.log("enter radvd start");
            cmd = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c '/etc/init.d/radvd start'";
             execAsync(cmd);
            return {"status":"radvd " + updateData.operation +" success!"};
        } else if(updateData.operation == "stop") {
            cmd = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c '/etc/init.d/radvd stop'";
            var cmd_rm_lease = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'rm /var/lib/dhcpv6/client.lease'";
            return execAsync(cmd).then(function(error){
                var errorResp = commonOper.handleError(error);
                if(errorResp.errorMessage !== null) {
                    console.log(errorResp.errorMessage);
                }
                execAsync(cmd_rm_lease).then(function(err){if(err) console.log(err);});
                return {"status":"radvd " + updateData.operation +" success!"};
            });
        } else {
            console.log("enter radvd restart");
            updateData.operation = "restart";
            cmd = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c '/etc/init.d/radvd stop'";
            var cmd_start ="docker exec -i "+ updateData["docker-name"] + " /bin/bash -c '/etc/init.d/radvd start'";
             execAsync(cmd).then(function(error){
                 execAsync(cmd_start).then(function(error){
                     var errorResp = commonOper.handleError(error);
                     if(errorResp.errorMessage !== null) {
                         console.log(errorResp.errorMessage);
                     }
                });
            });
            return {"status":"radvd " + updateData.operation +" success!"};
        }
    },
    dibblerOperation:function(updateData) {
        var cmd = "";
        if(updateData.operation == "start") {
            cmd = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'dibbler-server start'";
            return execAsync(cmd).then(function(error){
                var errorResp = commonOper.handleError(error);
                if(errorResp.errorMessage !== null) {
                    console.log(errorResp.errorMessage);
                }
                return {"status":"dibbler " + updateData.operation +" success!"};
            });
        } else if(updateData.operation == "stop") {
                var cmd_stop  = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'ps -aux |grep dibbler'";
                var cmd_kill  = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'kill -9  '";
                stopOper.stop(cmd_stop,"start",
                    "Stop dibbler-server success!","dibbler-server",cmd_kill);
                return {"status":"dibbler " + updateData.operation +" success!"};
        } else {
            updateData.operation = "restart";
            cmd = "docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'dibbler-server stop'";
            var cmd_start ="docker exec -i "+ updateData["docker-name"] + " /bin/bash -c 'dibbler-server start'";
            return execAsync(cmd).then(function(error){
                return execAsync(cmd_start).then(function(error){
                    var errorResp = commonOper.handleError(error);
                    if(errorResp.errorMessage !== null) {
                        console.log(errorResp.errorMessage);
                    }
                    return {"status":"radvd " + updateData.operation +" success!"};
                });
            });
        }
    }
}