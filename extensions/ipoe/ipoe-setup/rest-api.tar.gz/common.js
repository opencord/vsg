/**
 * File:         common.js
 * Contents:     Public method
 */

module.exports= {
	rep_spi_space: function (line) {
		line = line.replace(/(^\s*)|(\s*$)/g, "");
		var spistr = line.split(" ");
		return spistr;
	},
	modifiedDhcp6cRequest: function (line, name, updateData) {
		console.log("enter modifiedDhcp6c Request:" + name);
		if (updateData[name.substring(0, name.length - 1)] == undefined) {
			return line;
		} else if (updateData[name.substring(0, name.length - 1)]) {
			line = "       request " + name;
		} else {
			line = "       #request " + name;
		}
		return line;
	},
	modifiedDhcp6cSend: function (line, name, updateData) {
		if (updateData[name] == undefined) {
			return line;
		} else if (updateData[name]) {
			line = "       send authentication vcpe-secret-auth;";
		} else {
			line = "       #send authentication vcpe-secret-auth;";
		}
		return line;
	},
	modifiedDhcp6Keyinfo: function (line, spistr, updateData, keyinfo) {
		if(updateData[keyinfo] == undefined) {
			return line;
		}
		if (updateData[keyinfo].realm !== undefined ||
			updateData[keyinfo].keyid !== undefined ||
			updateData[keyinfo].secret !== undefined) {
			if (spistr[0] == "realm") {
				if(updateData[keyinfo].realm == undefined) {
					return line;
				}
				line = "        " + spistr[0] + " " + '\"' + updateData[keyinfo].realm + '\";';
			}
			if (spistr[0] == "keyid") {
				if(updateData[keyinfo].keyid == undefined) {
					return line;
				}
				line = "        " + spistr[0] + " " + updateData[keyinfo].keyid + ";";
			}
			if (spistr[0] == "secret") {
				if(updateData[keyinfo].secret == undefined) {
					return line;
				}
				line = "        " + spistr[0] + " " + '\"' + updateData[keyinfo].secret + '\";';
			}
		}
		return line;
	},
	modifiedDhcp6Option: function (line, spistr, updateData,name) {
		if(updateData[name] !== undefined) {
			line = "option " + name + " "+ updateData[name] +";";
		}
		return line;
	},
	modifiedDhcp6Host: function (line,spistr,updateData,name) {
		if(updateData["host"] !== undefined &&updateData["host"][name] !== undefined ) {
			line = "        " + name  + " " + updateData["host"][name] + " infinity;";
		}
		return line;
	},
	createDhcp6sKeyinfo:function (line,createData) {
		for(var i = 0;i<createData.number;i++) {
			var vlanId = 134
			if(createData.ctag !== undefined) {
				vlanId =  createData.ctag +i ;
			}
			var keyid = i+1;
			if(i == 0) {
				line = "keyinfo vcpe-" +vlanId + "-secret-key {" + "\n";
			} else {
				line += "keyinfo vcpe-" +vlanId + "-secret-key {" + "\n";
			}
			line += "        realm " + '\"fj-ipoe-' + vlanId+ '.net\";' + "\n";
			line += "        keyid " + keyid +";" + "\n";
			line += "        secret " +"\"ZmotaXBvZS1wYXNzd2Q=\";" + "\n";
			line += "};" +"\n";
		}
		console.log("retrun createDhcp6sKeyinfo: "+line);
		return line;
	},
	createDhcp6sHost:function(line ,createData) {
		for(var i = 0;i<createData.number;i++) {
			var duidPrefix = "00:03:00:01:00:00:0E:10:";
			var ads = "FD64:8D64:AF0C:1::1086";
			var perfix = "FD64:8D64:AF0C::/48";
			var vlanId = 134;
			var stag = 34;
			if(createData.address !== undefined ) {
				ads = createData.address;
			}
			if(createData.perfix !== undefined) {
				perfix  = createData.prefix;
			}
			if(createData.ctag !== undefined) {
				vlanId =  createData.ctag +i ;
			}
			if(createData.stag !== undefined) {
				stag = createData.stag;
			}
			var stag_hex = stag % 250;
			var ctag_hex = vlanId % 250;
			var stag_mod_hex = stag_hex<16?"0"+stag_hex.toString(16).toUpperCase():stag_hex.toString(16).toUpperCase();
			var ctag_mod_hex = ctag_hex<16?"0"+ctag_hex.toString(16).toUpperCase():ctag_hex.toString(16).toUpperCase();
			var adsPrefix =ads.substring(0,ads.length-4);
			var adsValue = parseInt(ads.substring(ads.length-4)) + i;
			if(i == 0) {
				line = "host vcpe-"+stag+"-"+vlanId+" {" +"\n";
			} else {
				line += "host vcpe-"+stag+"-"+vlanId+" {" +"\n";
			}
			line += "        duid" + " " +duidPrefix + stag_mod_hex +":"+ctag_mod_hex + ";\n";
			line +="        prefix " + perfix +" infinity;" + "\n";
			line += "        address" + " " +adsPrefix + adsValue +" infinity;" + "\n";
			line +="        delayedkey vcpe-" +vlanId + "-secret-key;"+"\n";
			line += "};"+"\n";
		}
		console.log("retrun createDhcp6sKeyinfo: "+line);
		return line;
	},
	updateVpceDockerName: function(oldName,newNameVaule) {
		var lastName = oldName;
		console.log("lastName start:"+ lastName);
		console.log("newName start:"+ newNameVaule);
		var str = newNameVaule.split(",");
		var newName = [];
		for(var i= 0;i<str.length;i++) {
			if(str[i].match(":")) {
				var tmp = str[i].split(":");
				var tmpObj = "";
				if(tmp.length > 2) {
					tmpObj = {"key":tmp[0],"value":tmp[1],"pc":tmp[2]};
				} else {
					tmpObj = {"key":tmp[0],"value":tmp[1]};
				}
				newName.push(tmpObj);
			}
		}
		for(var i = 0;i<newName.length;i++) {
			var newValue ="";
			if(newName[i]["pc"] == undefined) {
				newValue = newName[i]["key"] +":" + newName[i]["value"];
			} else {
				newValue = newName[i]["key"] +":" + newName[i]["value"]+ ":"+newName[i]["pc"];
			}
			if(oldName.match(newName[i]["key"])) {
				var reg = new RegExp(newName[i]["key"] + ":.*ble","g");
				console.log("reg :"+reg);
				var str = reg.exec(oldName);
				console.log("str:"+str);
				var strmatch = str[0].split(",");
				console.log("strmatch: "+strmatch[0]);
				console.log("newValue: "+newValue);
				lastName  = lastName.replace(strmatch[0],newValue);
				console.log("lastName:"+lastName);
			} else {
				lastName += "," + newValue;
			}
		}
		return lastName;
	},
	updateRequestParams : function(oldParmas,newParamsValue) {
		var lastParams = oldParmas;
		var str = newParamsValue.split(",");
		var newParams = [];
		for(var i= 0;i<str.length;i++) {
			var tmpObj = {"name":str[i]};
			newParams.push(tmpObj);
		}
		for(var i = 0;i<newParams.length;i++) {
			if(oldParmas.match(newParams[i]["name"]) == null) {
				lastParams += "," + newParams[i]["name"];
			}
		}
		return lastParams;
	},
	handleError:function(error)  {
		var data = {"errorMessage":null};
		if(error.cause !== undefined) {
			data = {"errorMessage":error.cause}
		}
		return data;
	}
}
