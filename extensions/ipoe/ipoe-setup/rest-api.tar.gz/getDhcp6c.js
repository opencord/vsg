/**
 * File:         getDhcp6s.js
 * Contents:     get data from dhcp6c.conf
 */

var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
var Promise=require('bluebird')
var execAsync=Promise.promisify(require('child_process').exec);

module.exports= {
    getDhcp6c: function(content,stag,ctag,dockername) {
        var cmd = "docker exec -i "+ dockername + " /bin/bash -c 'cat /var/lib/dhcpv6/dhcp6c_duid_value'";
        return execAsync(cmd).then(function(data) {
            console.log("read duid value"+data);
            var data = data.replace(/(^\s*)|(\s*$)/g, "");
            // get duid value start
            var value ="";
            for(var i= 0;i<data.length;i++) {
                if(i%2 == 0 && i !== 0) {
                    value += ":";
                }
                value += data[i];
            }
            console.log("get duid value:"+value);
            // get duid value stop
            //get dhcp6c config data
            var result = "{";
            result += "\""+"generate_conf_file" +"\":\""+"dhcp6c-"+stag+"-"+ctag+".conf"+"\"";
            result += ",\""+"running_config_file_name" +"\":\""+"dhcp6c.conf"+"\"";
            result +=",\""+"client_duid" +"\":\""+value+"\"";
            result += ",\""+"running_config_file_contents"+"\":"+" [{"
            var str = content.split('\n')
            var flagInitObj = true;
            var flagkeyinfo = true;
            if(str.length>0)
            {
                for(var i = 0 ; i < str.length-1; i++) {
                    var strr='';
                    if(str[i].match("#") !== null )  {
                        continue;
                    } else {
                        if(str[i].match("keyinfo")) {
                            var spistr = commonOper.rep_spi_space(str[i]);
                            if(flagInitObj) {
                                strr += '\"' + spistr[1] + '\":{\"' ;
                                flagInitObj = false;
                            } else {
                                strr += ',\"' + spistr[1] + '\":{\"' ;
                            }
                        }
                        if(str[i].match("realm") || str[i].match("keyid") || str[i].match("secret")) {
                            if(str[i].match("keyinfo") || str[i].match("authentication vcpe-secret-auth ") ) {
                                result += strr;
                                continue;
                            }
                            if(str[i].match("send authentication")) {
                                if(flagInitObj) {
                                    strr += '\"' + "authentication"+ '\":' + true +"}";
                                    flagInitObj = false;
                                }else {
                                    strr += ',\"' + "authentication"+ '\":' + true +"}";
                                }
                                result += strr;
                                continue;
                            }
                            var spistr = commonOper.rep_spi_space(str[i]);
                            if(spistr[1].indexOf("\"")>-1) {
                                spistr[1] = spistr[1].substring(1,spistr[1].length-1);
                            }
                            if(flagkeyinfo) {
                                strr +=  spistr[0]+ '\":\"' + spistr[1].substring(0,spistr[1].length-1) + '\"';
                                flagkeyinfo = false;
                            } else {
                                strr += ',\"' + spistr[0]+ '\":\"' + spistr[1].substring(0,spistr[1].length-1) + '\"';
                            }
                            if(str[i+1].match("};")) {
                                strr += '}';
                            }
                        }
                        if(str[i].match("interface")) {
                            if(str[i].match("prefix-interface")) {
                                continue;
                            }
                            var spistr = commonOper.rep_spi_space(str[i]);
                            if(flagInitObj) {
                                strr += '\"'+spistr[0] +'\":{';
                                strr += '\"'+ "value" + '\":\"' +spistr[1] + '\"';
                                flagInitObj = false;
                            } else {
                                strr += ',\"'+spistr[0] +'\":{';
                                strr += '\"'+ "value" + '\":\"' +spistr[1] + '\"';
                            }
                        }

                        if(str[i].match("request")) {
                            var spistr = commonOper.rep_spi_space(str[i]);
                            if(flagInitObj) {
                                strr += '\"' + spistr[1].substring(0,spistr[1].length-1)+ '\":' + true + '';
                                flagInitObj = false;
                            } else {
                                strr += ',\"' + spistr[1].substring(0,spistr[1].length-1)+ '\":' + true + '';
                            }
                        }
                        if(str[i].match("sla-id")) {
                            var spistr = commonOper.rep_spi_space(str[i]);
                            var tmpstr = commonOper.rep_spi_space(str[i-1]);
                            if(flagInitObj) {
                                strr += '\"'+tmpstr[0] +'\":{';
                                strr += '\"'+ "value" + '\":\"' +tmpstr[1] + '\"';
                                strr += '\"' + spistr[0]+ '\":\"' + spistr[1].substring(0,spistr[1].length-1) + '\"}';
                                flagInitObj = false;
                            } else {
                                strr += ',\"'+tmpstr[0] +'\":{';
                                strr += '\"'+ "value" + '\":\"' +tmpstr[1] + '\"';
                                strr += ',\"' + spistr[0]+ '\":\"' + spistr[1].substring(0,spistr[1].length-1) + '\"}';
                            }
                        }
                    }
                    result += strr;
                }
            }
            result += '}]}';
            console.log("result:"+result);
            var jsonSta = eval('(' +result +')')
            return jsonSta;
        })
    },//Parsing dhcp6c.conf files
    getdhcp6cStatus: function (content,key,name) {
        console.log("    key:"+key + "    name :"+name);
        var result = "{";
        var str = content.split('\n');
        if(str.length>0) {
            var flag = true;
            for (var i = 0; i < str.length - 1; i++) {
                var strr = '';
                console.log("str[i]: "+ str[i]);
                if((str[i].match("/usr/sbin/dhcp6c") || str[i].match("/etc/wide-dhcpv6")) && flag) {
                    strr += '\"'+ "status" + '\":\"'+"Running" +"\"";
                    flag = false;
                }
                if(flag) {
                    flag = false;
                    strr += '\"'+ "status" + '\":\"'+"Stopped" +"\"";
                }
                result += strr;
            }
        }
        result += '}';
        return result;
    } // get wide-dhcp6c status
}




