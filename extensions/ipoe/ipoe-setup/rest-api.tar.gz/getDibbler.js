/**
 * File:         getDibbler.js
 * Contents:     get data from /etc/dibbler/server.conf
 */

var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
module.exports= {
    getDibblerServer: function(content) {
        var result = "{'config_file_name':'server.conf','config_file_contents':[{";
        var str = content.split('\n');
        var flagInitObj = true;
        if(str.length>0) {
            for (var i = 0; i < str.length - 1; i++) {
                var strr='';
                if(str[i].match("#")) {
                    continue;
                }
                if(str[i].match("log-level") || str[i].match("log-mode")) {
                    var spistr = commonOper.rep_spi_space(str[i]);
                    if(flagInitObj) {
                        strr += '\"' + spistr[0] + '\":\"'+spistr[1] + '\"';
                        flagInitObj = false;
                    } else {
                        strr += ',\"' + spistr[0] + '\":\"'+ spistr[1] +'\"';
                    }
                }
                if(str[i].match("stateless")) {
                    var spistr = commonOper.rep_spi_space(str[i]);
                    if(flagInitObj) {
                        strr += '\"' + spistr[0] + '\":'+true ;
                        flagInitObj = false;
                    } else {
                        strr += ',\"' + spistr[0] + '\":'+ true ;
                    }
                }
                if(str[i].match("iface")) {
                    var spistr = commonOper.rep_spi_space(str[i]);
                    if(flagInitObj) {
                        strr += '\"' + spistr[0] + '\":{';
                        flagInitObj = false;
                    } else {
                        strr += ',\"' + spistr[0] + '\":{';
                    }
                    strr += '\"' + "value" + '\":\"'+spistr[1] + '\"';
                }
                if(str[i].match("dns-server") || str[i].match("domain")
                    || str[i].match("ntp-server")) {
                    var ss = str[i].replace(/\s+/g, ' ');
                    var spistr = commonOper.rep_spi_space(ss);
                    if(flagInitObj) {
                        strr += '\"' + spistr[1] + '\":\"'+spistr[2] + '\"';
                        flagInitObj = false;
                    } else {
                        strr += ',\"' + spistr[1] + '\":\"'+ spistr[2] +'\"';
                    }
                }
                result += strr;
            }
        }
        result += '}}]}';
        return result;
    },//Parsing dhcp6s.conf files
    getStatus: function (content,key,name) {
        console.log("    key:"+key + "    name :"+name);
        var result = "{";
        var str = content.split('\n');
        if(str.length>0) {
            var flag = true;
            for (var i = 0; i < str.length - 1; i++) {
                var strr = '';
                console.log("str[i]: "+ str[i]);
                if(str[i].match(key) && flag) {
                    strr += '\"'+ "status" + '\":\"'+"Running" +"\"";
                    flag = false;
                }
                if(flag) {
                    flag = false;
                    strr += '\"'+ "status" + '\":\"'+"Stopped" +"\"";
                }
                result += strr;
            }
        }
        result += '}';
        return result;
    }
}




