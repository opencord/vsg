/**
 * File:         getLeaseInfo.js
 * Contents:     get data from /var/lib/dhcpv6/client.lease or /var/lib/dhcpv6/server6.lease
 */

var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
var formatOper = require(__dirname + '/formatDate');
module.exports= {
    getDhcp6cLease: function(content) {
        var result = "{";
        var str = content.split('\n');
        var flagInitObj = true;
        if(str.length>0) {
            for (var i = 0; i < str.length - 1; i++) {
                var strr='';
                console.log("str:"+str[i]);
                var spistr = commonOper.rep_spi_space(str[i]);
                if(spistr[0] == "start-time") {
                    var time = str[i].replace(/(^\s*)|(\s*$)/g, "");
                    console.log("time:"+time);
                    spistr[1] = formatOper.format(time.substring(10), 'yyyy/MM/dd HH:mm:ss')
                }
                if(flagInitObj) {
                    strr += '\"' + spistr[0]+ '\":\"' + spistr[1] + '\"';
                    flagInitObj = false;
                } else {
                    strr += ',\"' + spistr[0]+ '\":\"' + spistr[1] + '\"';
                }
                result += strr;
            }
            result += '}';
        } else {
            result +="'message':'No Lease information available'}";
        }
        console.log("result:"+result);
        return result;
    },
    getDhcp6sLease: function(content) {
        var result = "{";
        var str = content.split('\n');
        var flagInitObj = true;
        if(str.length>0) {
            result += "'host':[";
            for (var i = 0; i < str.length - 1; i++) {
                var strr='';
                console.log("str:"+str[i]);
                if(str[i].match("{")) {
                    result += '{';
                    flagInitObj = true;
                    continue;
                }
                if(str[i].match("}")) {
                    result += '},';
                    continue;
                }
                var spistr = commonOper.rep_spi_space(str[i]);
                if(flagInitObj) {
                    if((spistr[0] == "iaprefix" || spistr[0] == "start-time")&& spistr.length >2) {
                        strr += '\"' + spistr[0]+ '\":\"' + spistr[1]  +" " + spistr[2] +'\"';
                    } else {
                        strr += '\"' + spistr[0]+ '\":\"' + spistr[1] + '\"';
                    }
                    flagInitObj = false;
                } else {
                    if((spistr[0] == "iaprefix" || spistr[0] == "start-time")&& spistr.length >2) {
                        strr += ',\"' + spistr[0]+ '\":\"' + spistr[1]  +" " + spistr[2] +'\"';
                    }else {
                        strr += ',\"' + spistr[0]+ '\":\"' + spistr[1] + '\"';
                    }
                }
                result += strr;
            }
            result += ']}';
        } else {
            result +="'message':'No Lease information available'}";
        }
        console.log("result:"+result);
        return result;
    }
}