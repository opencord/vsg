/**
 * File:         startAllServer.js
 * Contents:     start all server process
 */

var __dirname = "/usr/local/lib/node_modules";
var restartOper = require(__dirname + '/restartServer');
var stopAllOper = require(__dirname + '/stopAllServer');
var getOper = require(__dirname + '/getConfData');

module.exports={
    startAll:function(updateData) {
        var resProm ;
        stopAllOper.stopAll({"operation":"stop","docker-name":updateData["docker-name"]});
        setTimeout(function(){
            resProm = restartOper.dhcp6cOperation({"operation":"start","docker-name":updateData["docker-name"]});
        },1000*7);
        if(resProm !== undefined) {
            resProm.then(function(data){
                console.log(data);
                return data;
            })
        } else {
            return {"state":"Docker is not running or IPv6 is not enabled"};
        }
    }
}