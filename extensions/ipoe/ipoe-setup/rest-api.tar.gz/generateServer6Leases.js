/**
 * File:         generateServer6Leases.js
 * Contents:     generate server6.leases to /var/lib/dhcpv6/server6.leases
 */

var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
var Promise=require('bluebird');
var execAsync=Promise.promisify(require('child_process').exec);
var getOper = require(__dirname + '/getConfData');

module.exports= {
    generateDhcp6sLease: function() {
        console.log("enter generate server6 leases file...");
        return execAsync("/tmp/extract-dhcp6-leases.sh /tmp/dhcp6-cap.log").then(function(){
            var result = getOper.getDhcp6sLeaseInfo();
            return result;
        }).catch(function(error){
            //console.log(error.cause);
            var errorResp = commonOper.handleError(error);
            if(errorResp.errorMessage !== null) {
                console.log(errorResp.errorMessage);
            }
            return{"state":"No Lease information available."};
        });

    }
}