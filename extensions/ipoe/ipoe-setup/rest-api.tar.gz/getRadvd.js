/**
 * File:         getRadvd.js
 * Contents:     get data from /etc/radvd.conf
 */

var __dirname = "/usr/local/lib/node_modules";
var commonOper = require(__dirname + '/common');
module.exports= {
    getRadvd: function(content) {
        console.log("enter getRadvd");
        var result = "{'config_file_name':'radvd.conf','config_file_contents':[{";
        var str = content.split('\n');
        if(str.length>0) {
            for (var i = 0; i < str.length - 1; i++) {
                var strr='';
                if(str[i].match("#") || str[i].match("{") || str[i].match("}") ) {
                    if(str[i].match("interface eth")){
                        var spistr = commonOper.rep_spi_space(str[i]);
                        strr += '\"' + spistr[0] + '\":{';
                        strr += '\"' + "value" + '\":\"'+ spistr[1] +'\"';
                    }
                    if(str[i].match("AdvManagedFlag") ||str[i].match("AdvOtherConfigFlag")) {
                        var line = str[i].split(";");
                        var spistr = commonOper.rep_spi_space(line[0]);
                        strr += ',\"' + spistr[0] + '\":\"'+ spistr[1] +'\"';
                    }
                    result += strr;
                    continue;
                } else  if(str[i].match("prefix") || str[i].match("route") || str[i].match("RDNSS")) {
                    var spistr = commonOper.rep_spi_space(str[i]);
                    if(str[i].match("route") || str[i].match("RDNSS")) {
                        if(str[i].match("AdvRDNSSLifetime")) {
                            var line = str[i].split(";");
                            var spistr = commonOper.rep_spi_space(line[0]);
                            strr += ',\"' + spistr[0] + '\":\"'+ spistr[1] +'\"';
                            result += strr;
                            continue;
                        } else {
                            strr += '},\"' + spistr[0] + '\":{';
                        }
                    } else {
                        strr += ',\"' + spistr[0] + '\":{';
                    }
                    strr += '\"' + "value" + '\":\"'+ spistr[1] +'\"';
                }  else {
                    var line = str[i].split(";");
                    var spistr = commonOper.rep_spi_space(line[0]);
                    strr += ',\"' + spistr[0] + '\":\"'+ spistr[1] +'\"';
                }
                result += strr;
            }
        }
        result += '}}}]}';
        console.log("result:"+result);
        return result;
    },
    getRadvdStatus: function (content) {
        var result = "{";
        var str = content.split('\n');
        if(str.length>0) {
            var flag = true;
            for (var i = 0; i < str.length - 1; i++) {
                var strr = '';
                console.log("str[i]: "+ str[i]);
                if((str[i].match("/etc/radvd.conf") || str[i].match("/usr/sbin/radvd")) && flag) {
                    strr += '\"'+ "status" + '\":\"'+"Running" +"\"";
                    flag = false;
                }
                if(flag) {
                    flag = false;
                    strr += '\"'+ "status" + '\":\"'+"Stopped" +"\"";
                }
                result += strr;
            }
        }
        result += '}';
        return result;
    }
}




